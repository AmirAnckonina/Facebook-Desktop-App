﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using FacebookWrapper;

// $G$ THE-001 (-14) Your grade on diagrams document - 86. Please see comments inside the document. (40% of your grade).
// $G$ SFN-001 (-15) Program crashes when line newGroup.MembersCount = group.Members.Count; occurs.
// $G$ CSS-999 (-10) StyleCop errors.

namespace FacebookWinFormsApp
{
    public static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            Clipboard.SetText("design.patterns20cc");
            FacebookService.s_UseForamttedToStrings = true;
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            new AppManager().Run();
        }
    }
}
